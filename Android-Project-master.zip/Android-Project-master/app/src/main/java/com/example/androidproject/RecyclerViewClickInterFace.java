package com.example.androidproject;

public interface RecyclerViewClickInterFace {
    void onItemClick(int position);
}
